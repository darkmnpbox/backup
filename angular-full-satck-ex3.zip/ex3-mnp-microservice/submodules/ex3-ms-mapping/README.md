## MAP
    - This contain mapping for type and interface.