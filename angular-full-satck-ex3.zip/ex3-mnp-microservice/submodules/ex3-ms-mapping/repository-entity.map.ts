import { Repository } from "typeorm";

export type RepoEntity<T> = Record<string & keyof T, Repository<T[string & keyof T]>>;