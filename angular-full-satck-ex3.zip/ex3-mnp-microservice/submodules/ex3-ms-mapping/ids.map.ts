

export type IdsMap = Record<'id', number>