## FRAMEWORK GENERAL ENTITY
    - THis will framework will work with any entities for CURD opertaion and qurying with filter the database.
