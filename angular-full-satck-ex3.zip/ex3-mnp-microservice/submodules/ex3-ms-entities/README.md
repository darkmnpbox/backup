## Entity
    - This contain entities for Employee Department