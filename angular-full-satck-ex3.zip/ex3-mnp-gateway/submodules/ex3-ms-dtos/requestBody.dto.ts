
// for requesting a service in route
export default class RequestBodyDto {
    socketId: string;
    requestId: string;
    data: {};
}