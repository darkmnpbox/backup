const bodyParser = require("body-parser");
const cors = require("cors");
const http = require('http');
const express = require('express');
const socketIo = require("socket.io");
import axios, { AxiosRequestConfig, AxiosResponse } from 'axios';
import swaggerUI from 'swagger-ui-express';
const YAML = require('yamljs');
import { Dictionary } from 'dictionaryjs';
import { NextFunction, query, Request, Response } from 'express';
import RequestBodyDto from './submodules/ex3-ms-dtos/requestBody.dto';

require('dotenv').config();
const microserviceBaseUrl: string = process.env.MICROSERVICE_BASE_URL || `http://localhost:4001`;
const port: number = process.env.PORT ? parseInt(process.env.PORT) : 4002;

const userInfoEndPoint = 'https://idsvr4.azurewebsites.net/connect/userinfo';

// load apiswagger configuration
const swaggerJsDocs = YAML.load('./api.yaml');


import { Broker } from './submodules/rabbitmq-broker/broker';
import ResponseModel from './submodules/ex3-ms-dtos/responseModel';

// create app instance
const app = express();


// used build in middlewares
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cors());

// setup swagger configuration
app.use('/api-gateway', swaggerUI.serve, swaggerUI.setup(swaggerJsDocs));



// running app http server
const server = http.createServer(app);

// book keeping of connected devices and running queues
let activeConnectionDict = new Dictionary();
let deviceAuthenticatedDict = new Dictionary();


// middlewares

const tokenAuthenticationMiddleware = async (req: Request, res: Response, next: NextFunction) => {

    try {
        const token = req.headers.authorization?.toString()?.slice(7);
        const socketId = req.params.socketId;
        if (token) {
            let config: AxiosRequestConfig = {
                headers: {
                    "Authorization": `Bearer ${token}`,
                    "Content-Type": "application/json"
                }
            };
            const response: AxiosResponse<any> = await axios.get(userInfoEndPoint, config);
            if (response.statusText !== 'OK') throw Error('Token not valid');
            const socketId = req.params.socketId;
            deviceAuthenticatedDict.set(socketId, response.data);
            next();
        } else {
            const response = new ResponseModel(400, 'FAILED', 'GET', `Unable to authenticate socket: ${socketId}`, {})
            console.log('called Autheication failed', deviceAuthenticatedDict);
            res.status(400).json(response);
        }

    } catch (error) {
        const response = new ResponseModel(400, 'FAILED', 'GET', `Unable to authenticate socket: ${error?.message}`, {})
        console.log('called Autheication failed', deviceAuthenticatedDict);
        res.status(400).json(response);
    }
}

const tokenAuthorisationMiddleware = (req: Request, res: Response, next: NextFunction) => {
    try {
        const token = req.headers.authorization?.toString()?.slice(7);
        const socketId = req.params.socketId
        if (token) {
            console.log(deviceAuthenticatedDict.getKeys(), socketId);
            if (!deviceAuthenticatedDict.getKeys().includes(socketId)) throw Error('Not Authenticated');
            next();
        } else {
            const response = new ResponseModel(400, 'FAILED', 'GET', `Unable to authorize socket: ${socketId}`, {})
            res.status(400).json(response);
        }
        console.log('called Auth ok', deviceAuthenticatedDict);
    } catch (error) {
        const response = new ResponseModel(400, 'FAILED', 'GET', `Unable to authorize socket: ${error?.message}`, {})
        console.log('called Auth failed', deviceAuthenticatedDict);
        res.status(400).json(response);
    }
}


var sockets = [];

var broker = Broker.getInstance();

const io = socketIo(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST", "HEAD", "OPTIONS"],
        allowedHeaders: ["my-custom-header"],
        credentials: false,
    },
});

io.on("connection", (socket) => {
    console.log(`client with id : ${socket.id} connected to apigateway`);
    // add to sockets
    sockets.push(socket);
    // adding to active connection dictonary
    activeConnectionDict.set(socket.id, socket);
    console.log("number of client connected : ", activeConnectionDict.length);
    // sending message to client: acknowledgement of connection
    socket.emit("socketIdFromServer", { socketId: socket.id });
    socket.on("disconnect", () => {
        console.log("Client disconnected", socket.id);
        // remove soket id from active-connection dictonary
        activeConnectionDict.remove(socket.id);
        deviceAuthenticatedDict.remove(socket.id);
        // remove soket id from socket-device dictonary
        console.log("number of client connected : ", activeConnectionDict.length);
        socket.disconnect(true);
    });
});

// starting the routes

app.get('/connectdevice/:id/:socketId', tokenAuthenticationMiddleware, async (req: Request, res: Response) => {
    const userId = req.params.userId;
    const socketId = req.params.socketId;
    const deviceId = req.params.id;
    console.log('connected to socket :- ', socketId);
    const response = new ResponseModel(200, 'SUCCESS', 'GET', `Authentication Completed for socket ${socketId}`, {});
    res.status(200).json(response);
});




// getting a specific service object with id

app.get("/:socketId/:serviceName/:service/:id", tokenAuthorisationMiddleware, async (req: Request, res: Response) => {
    const service = req.params.service;
    const id = req.params.id;
    const url = microserviceBaseUrl + "/" + service + "/" + id;
    try {
        const result = await axios.get(url);
        res.status(200).json(result.data);
    } catch (error) {
        console.log(error.message);
        const response = new ResponseModel(400, 'FAILED', 'GET', `Unalble to fetch the ${service} with Id: ${id}`, {})
        res.status(400).json(response);
    }
}
);

// getting a service all objects
app.get("/:socketId/:serviceName/:service", tokenAuthorisationMiddleware, async (req: Request, res: Response) => {
    const service = req.params.service;
    const query = req.query.query;
    const url = microserviceBaseUrl + "/" + service + (query ? "?query=" + query : "");
    try {
        const result = await axios.get(url);
        res.status(200).json(result.data);
    } catch (error) {
        console.log(error.message);
        const response = new ResponseModel(500, 'FAILED', 'GET', `Unalble to fetch all the ${service}S`, {});
        res.status(400).json(response);
    }
})

// create a specific service object with data
app.post("/:socketId/:serviceName/:service", tokenAuthorisationMiddleware, async (req: Request, res: Response) => {
    const requestBody: RequestBodyDto = req.body;
    const exchangeName = req.params.service + "_ADD";
    const response = broker.publishMessageToTopic(
        exchangeName,
        requestBody,
    );
    res.status(response.statusCode).json(response);
});

// update a specific service object with id and data
app.put("/:socketId/:serviceName/:service/:id", tokenAuthorisationMiddleware, async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    const requestBody: RequestBodyDto = req.body;
    requestBody.data['id'] = id;
    const exchangeName = req.params.service + "_UPDATE";
    const response = broker.publishMessageToTopic(
        exchangeName,
        requestBody
    );
    res.status(response.statusCode).json(response);

});

// delete a specific service object with id
app.delete("/:socketId/:serviceName/:service/:id", tokenAuthorisationMiddleware, async (req: Request, res: Response) => {
    const id: number = parseInt(req.params.id);
    const body = req.query.body;
    console.log(body);
    const requestBody: RequestBodyDto = typeof body === 'string' ? JSON.parse(body) : { socketId: '', requestId: '', data: {} };
    requestBody['data'] = { id };
    const exchangeName = req.params.service + "_DELETE";
    const response = broker.publishMessageToTopic(
        exchangeName,
        requestBody
    );
    res.status(response.statusCode).json(response);
});


// Listening to port and created exchanges
server.listen(port, () => {
    broker.listenToServices("API_GATEWAY_SERVICE", (result) => {
        const { message } = result;
        console.log('message recieved from MS to gateway lisnter', message);
        //getting the browser socket to hom the response needs to be send
        let vSocket: any = activeConnectionDict.get(message.socketId);
        if (vSocket) {
            console.log("response to client to call call back function", message);
            vSocket.emit("successResponseFromServer", message);
        } else {
            console.log(`client with socket id : ${message.socketId} diconnected... unable to emit message`);
        }
    });
    broker.listenToServices("ERROR_RECEIVER", (result) => {
        let { message } = result;
        console.log(message, 'message from MS');
        let vSocket: any = activeConnectionDict.get(message.socketId);
        if (vSocket) {
            vSocket.emit("errorResponseFromServer", message);
        } else {
            console.log(`client with socket id : ${message.socketId} diconnected... unable to emit message`);
        }
    });
    console.log(`gateway is listening on http://localhost:${port}`);
    console.log(`gateway swagger documentation is listening on http://localhost:${port}/api-gateway`);
});
