import { SocketIoConfig } from "ngx-socket-io";


const socketIOConfig: SocketIoConfig = { url: 'http://localhost:4002' };

export default socketIOConfig;