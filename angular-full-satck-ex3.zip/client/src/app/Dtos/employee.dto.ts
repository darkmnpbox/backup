
// this is the employee dto
export default class EmployeeDto {
    id?: number;
    name?: string;
    age?: number;
    departments?: number[];
}