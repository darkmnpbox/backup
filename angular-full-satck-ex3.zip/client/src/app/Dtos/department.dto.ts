

// this is the department dto
export default class DepartmentDto {
    id?: number;
    name?: string;
    employees?: number[];

}