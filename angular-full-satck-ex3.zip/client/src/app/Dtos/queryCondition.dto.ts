
// this will query constions
export default class QueryCondition {

    columnName!: string;
    columnType!: 'string' | 'number';
}