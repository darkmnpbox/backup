## Data Trasnsfer Objects
    - this will contain Dtos required Employee and Department.